from flask import Flask, render_template, request
from flask_seasurf import SeaSurf
from flask_talisman import Talisman


app = Flask(__name__)
app.secret_key = '123'
csrf = SeaSurf(app)

SELF = "'self'" # source of current domain (but not sub-domain)
UNSAFE_INLINE = "'unsafe-inline'" # allows DOM in-line resources (<script> elements)
UNSAFE_EVAL = "'unsafe-eval'" # allows the use of JS eval()
NONE = "'none'" # nothing gets loaded
ANY = '*' # load from anywhere

talisman = Talisman(
    app,
    content_security_policy={
        'default-src': [
            NONE,
        ],
        'script-src': [
            'https://ajax.googleapis.com',
            # UNSAFE_EVAL,
            # UNSAFE_INLINE,
        ],
        'frame-src': ["'self'"]
    },
   content_security_policy_nonce_in=['script-src'],
)


@app.route('/', methods=['GET', 'POST'])
def index():
    message = request.form.get('message', None)
    return render_template('index.html', message=message)

# Example of a route-specific talisman configuration
@app.route('/embeddable')
@talisman(
    # frame_options='deny'
    # frame_options='allow-from localhost', # works in Firefox but not Chrome
    frame_options='sameorigin' # requires to have at least content_security_policy={ 'frame-src': ["'self'"] }
)
def embeddable():
    return "<html>I can be embedded.</html>"


@app.route('/the_embedder', methods=['GET'])
def embedder():
    return '<iframe src="' + request.url_root + '/embeddable' + '"/>'


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=443, debug=True)
