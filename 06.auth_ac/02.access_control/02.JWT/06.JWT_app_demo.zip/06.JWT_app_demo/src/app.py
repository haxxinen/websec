import datetime
from flask import Flask, render_template, request, redirect, url_for, make_response
import jwt

app = Flask(__name__)

# RSA keys used for JWT signing
with open('private_key.pem') as f:
    PRIVATE_KEY = f.read()
with open('public_key.pem') as f:
    PUBLIC_KEY = f.read()

USERS = {
    "alice": "password1234",
    "admin": "bossman"
}

@app.route("/")
def index():
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    else:
        username = request.form["username"]
        password = request.form["password"]
        if username in USERS and USERS.get(username) == password:
            response = make_response(redirect(url_for("profile")))
            response.set_cookie('token', value=create_token(username))
            return response
        else:
            return render_template("login.html",
                error="Invalid username or password")

@app.route("/logout")
def logout():
    response = make_response(redirect(url_for("login")))
    response.set_cookie('token', '', expires=0)
    return response

@app.route("/profile")
def profile():
    token = request.cookies.get('token')
    if not token:
        return make_response('Unauthorized login.', 401)
    err, payload = decode_token(token)
    if err is not None:
        return make_response(str(err), 401)
    return render_template("profile.html", user=get_current_user(payload))

def create_token(username):
    return jwt.encode({'username' : username, 'exp' : datetime.datetime.utcnow() + datetime.timedelta(minutes=10)}, PRIVATE_KEY, algorithm='RS256')

def decode_token(token):
    try:
        data = jwt.decode(token, PUBLIC_KEY, algorithm='RS256')
    except Exception as e:
        return e, None
    return None, data

def get_current_user(payload):
    user = payload['username']
    return user
